import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { BrainCog, BookOpen, PenTool, Calendar, BarChart3, Menu } from 'lucide-react';
import { Button } from './components/ui/button';
import { Card } from './components/ui/card';
import ChecklistEstudos from './components/ChecklistEstudos';
import CicloRevisao from './components/CicloRevisao';
import AreaRedacao from './components/AreaRedacao';
import PainelDesempenho from './components/PainelDesempenho';
import Simulados from './components/Simulados';
import Cronograma from './components/Cronograma';

function MainContent() {
  return (
    <div className="min-h-screen bg-background">
      <header className="fixed top-0 left-0 right-0 z-50">
        <div className="container">
          <div className="glass-effect flex h-20 items-center justify-between rounded-b-2xl px-6">
            <div className="flex items-center gap-8">
              <h1 className="text-2xl font-bold text-white">Vizione</h1>
              <nav className="hidden md:block">
                <ul className="flex gap-6 text-neutral-light">
                  <li><a href="/" className="hover:text-white transition-colors">Início</a></li>
                  <li><a href="/simulados" className="hover:text-white transition-colors">Simulados</a></li>
                  <li><a href="/redacao" className="hover:text-white transition-colors">Redação</a></li>
                  <li><a href="/desempenho" className="hover:text-white transition-colors">Desempenho</a></li>
                </ul>
              </nav>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" className="md:hidden">
                <Menu className="h-5 w-5" />
              </Button>
              <Button variant="primary" size="sm" className="hidden md:inline-flex gradient-button">
                Começar Agora
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container pt-32 pb-16">
        <div className="mb-12 text-center">
          <h2 className="mb-4 text-4xl font-bold leading-tight md:text-5xl lg:text-6xl">
            Saber é 
            <span className="bg-gradient-to-r from-purple-primary to-purple-light bg-clip-text text-transparent"> recordar</span>
          </h2>
          <p className="text-neutral-light text-lg italic">_Platão</p>
          <p className="mx-auto max-w-2xl text-neutral-light mt-6">
            Prepare-se de forma inteligente com revisões personalizadas, simulados e feedback detalhado
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card variant="glass" className="group glass-card p-6 transition-all duration-300 hover:translate-y-[-4px] bg-gradient-to-br from-purple-primary/30 to-purple-light/30 border-purple-light/40 transform scale-105">
            <div className="mb-6 flex items-center justify-between">
              <BrainCog className="h-8 w-8 text-purple-light" />
              <span className="rounded-full bg-purple-primary/20 px-3 py-1 text-sm text-purple-light">
                Diário
              </span>
            </div>
            <h3 className="mb-3 text-xl font-semibold">Revisão Inteligente</h3>
            <p className="mb-6 text-neutral-light">
              Questões personalizadas baseadas no seu desempenho e cronograma
            </p>
            <Button className="w-full gradient-button" onClick={() => window.location.href = '/revisao'}>
              Iniciar Revisão Diária
            </Button>
          </Card>

          <Card variant="glass" className="group glass-card p-6 transition-all duration-300 hover:translate-y-[-4px]">
            <div className="mb-6 flex items-center justify-between">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-purple-primary/10">
                <span className="text-xl">📝</span>
              </div>
              <span className="rounded-full bg-purple-primary/10 px-3 py-1 text-sm text-purple-light">
                Registro
              </span>
            </div>
            <h3 className="mb-3 text-xl font-semibold">O que você estudou hoje?</h3>
            <p className="mb-6 text-neutral-light">
              Registre seus estudos e crie flashcards personalizados para reforçar o aprendizado
            </p>
            <Button className="w-full gradient-button" onClick={() => window.location.href = '/checklist'}>
              Registrar Estudos
            </Button>
          </Card>

          <Card variant="glass" className="group glass-card p-6 transition-all duration-300 hover:translate-y-[-4px]">
            <div className="mb-6 flex items-center justify-between">
              <BookOpen className="h-8 w-8 text-purple-light" />
              <span className="rounded-full bg-purple-primary/10 px-3 py-1 text-sm text-purple-light">
                Prática
              </span>
            </div>
            <h3 className="mb-3 text-xl font-semibold">Simulados</h3>
            <p className="mb-6 text-neutral-light">
              Simulados criados de acordo com o seu progresso no Vizione
            </p>
            <Button className="w-full gradient-button" onClick={() => window.location.href = '/simulados'}>
              Fazer Simulado
            </Button>
          </Card>

          <Card variant="glass" className="group glass-card p-6 transition-all duration-300 hover:translate-y-[-4px]">
            <div className="mb-6 flex items-center justify-between">
              <PenTool className="h-8 w-8 text-purple-light" />
              <span className="rounded-full bg-purple-primary/10 px-3 py-1 text-sm text-purple-light">
                Redação
              </span>
            </div>
            <h3 className="mb-3 text-xl font-semibold">Área de Redação</h3>
            <p className="mb-6 text-neutral-light">
              Editor completo com correção automática, timer e feedback detalhado
            </p>
            <Button className="w-full gradient-button" onClick={() => window.location.href = '/redacao'}>
              Praticar Redação
            </Button>
          </Card>

          <Card variant="glass" className="group glass-card p-6 transition-all duration-300 hover:translate-y-[-4px]">
            <div className="mb-6 flex items-center justify-between">
              <Calendar className="h-8 w-8 text-purple-light" />
              <span className="rounded-full bg-purple-primary/10 px-3 py-1 text-sm text-purple-light">
                Agenda
              </span>
            </div>
            <h3 className="mb-3 text-xl font-semibold">Cronograma</h3>
            <p className="mb-6 text-neutral-light">
              Organize seus estudos com um plano personalizado
            </p>
            <Button className="w-full gradient-button" onClick={() => window.location.href = '/cronograma'}>
              Ver Cronograma
            </Button>
          </Card>

          <Card variant="glass" className="group glass-card p-6 transition-all duration-300 hover:translate-y-[-4px]">
            <div className="mb-6 flex items-center justify-between">
              <BarChart3 className="h-8 w-8 text-purple-light" />
              <span className="rounded-full bg-purple-primary/10 px-3 py-1 text-sm text-purple-light">
                Análise
              </span>
            </div>
            <h3 className="mb-3 text-xl font-semibold">Desempenho</h3>
            <p className="mb-6 text-neutral-light">
              Acompanhe seu progresso com análises detalhadas
            </p>
            <Button className="w-full gradient-button" onClick={() => window.location.href = '/desempenho'}>
              Ver Desempenho Completo
            </Button>
          </Card>
        </div>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<MainContent />} />
        <Route path="/checklist" element={<ChecklistEstudos />} />
        <Route path="/revisao" element={<CicloRevisao />} />
        <Route path="/redacao" element={<AreaRedacao />} />
        <Route path="/desempenho" element={<PainelDesempenho />} />
        <Route path="/simulados" element={<Simulados />} />
        <Route path="/cronograma" element={<Cronograma />} />
      </Routes>
    </Router>
  );
}