import { HfInference } from '@huggingface/inference';

const ASSISTANT_ID = '6786ab6a4f61a3c75b28c714';
const hf = new HfInference(process.env.VITE_HUGGINGFACE_API_KEY);

export interface RedacaoCorrecao {
  nota: number;
  competencias: {
    comp1: number;
    comp2: number;
    comp3: number;
    comp4: number;
    comp5: number;
  };
  comentarios: string;
  pontosFortes: string[];
  pontosMelhoria: string[];
}

export async function corrigirRedacao(texto: string, tema: string): Promise<RedacaoCorrecao> {
  try {
    const response = await fetch(
      `https://api-inference.huggingface.co/models/chat-assistant/${ASSISTANT_ID}`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${process.env.VITE_HUGGINGFACE_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          inputs: {
            text: `Por favor, corrija a seguinte redação sobre o tema "${tema}":\n\n${texto}\n\nForneça uma análise detalhada incluindo nota (0-1000), avaliação por competência (0-200 cada), comentários gerais, pontos fortes e pontos para melhorar.`
          }
        })
      }
    );

    if (!response.ok) {
      throw new Error('Falha na comunicação com o Hugging Face');
    }

    const result = await response.json();
    return parseCorrecao(result.generated_text);
  } catch (error) {
    console.error('Erro ao corrigir redação:', error);
    throw new Error('Não foi possível corrigir a redação no momento. Tente novamente mais tarde.');
  }
}

function parseCorrecao(text: string): RedacaoCorrecao {
  return {
    nota: extractNota(text),
    competencias: extractCompetencias(text),
    comentarios: extractComentarios(text),
    pontosFortes: extractPontosFortes(text),
    pontosMelhoria: extractPontosMelhoria(text)
  };
}

function extractNota(text: string): number {
  const notaMatch = text.match(/Nota final\s*:\s*(\d+)\/1000/i);
  return notaMatch ? parseInt(notaMatch[1]) : 0;
}

function extractCompetencias(text: string): RedacaoCorrecao['competencias'] {
  const competencias = {
    comp1: 0,
    comp2: 0,
    comp3: 0,
    comp4: 0,
    comp5: 0
  };

  // Extrair valores das competências do texto
  const matches = text.matchAll(/\((\d+)\/(\d+)\)/g);
  const valores = Array.from(matches).map(match => parseInt(match[1]));

  // Mapear os valores encontrados para as competências
  if (valores.length >= 5) {
    competencias.comp1 = valores[0];
    competencias.comp2 = valores[1];
    competencias.comp3 = valores[2];
    competencias.comp4 = valores[3];
    competencias.comp5 = valores[4];
  }

  return competencias;
}

function extractComentarios(text: string): string {
  // Extrair o texto antes de "Sugestões de melhoria"
  const comentariosMatch = text.split('Sugestões de melhoria:')[0];
  return comentariosMatch.trim();
}

function extractPontosFortes(text: string): string[] {
  const pontosFortes = [];
  
  // Extrair pontos positivos mencionados no texto
  const matches = text.match(/([A-Z][^.!?]*(?:[.!?]+|$))/g);
  if (matches) {
    matches.forEach(sentence => {
      if (sentence.includes('bem') || 
          sentence.includes('excelente') || 
          sentence.includes('adequado') || 
          sentence.includes('eficaz')) {
        pontosFortes.push(sentence.trim());
      }
    });
  }
  
  return pontosFortes;
}

function extractPontosMelhoria(text: string): string[] {
  const pontosMelhoria = [];
  
  // Extrair sugestões de melhoria
  const sugestoesSection = text.split('Sugestões de melhoria:')[1];
  if (sugestoesSection) {
    const sugestoes = sugestoesSection
      .split('\n')
      .filter(line => line.trim().length > 0)
      .map(line => line.replace(/^[-•]/, '').trim())
      .filter(line => !line.includes('No geral')); // Remover a conclusão final
    
    pontosMelhoria.push(...sugestoes);
  }
  
  return pontosMelhoria;
}