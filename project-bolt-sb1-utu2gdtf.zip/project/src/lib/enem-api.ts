interface QuestaoENEM {
  id: string;
  ano: number;
  materia: string;
  assunto: string;
  enunciado: string;
  alternativas: {
    a: string;
    b: string;
    c: string;
    d: string;
    e: string;
  };
  gabarito: string;
  resolucao?: string;
}

const BASE_URL = 'https://raw.githubusercontent.com/yunger7/enem-api/main/data';

export async function buscarQuestoes(materia?: string, ano?: number): Promise<QuestaoENEM[]> {
  try {
    // Se não especificar matéria, busca o índice geral
    const url = materia 
      ? `${BASE_URL}/${materia.toLowerCase()}.json`
      : `${BASE_URL}/index.json`;
    
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error('Falha ao buscar questões');
    }

    let questoes = await response.json();

    // Filtrar por ano se especificado
    if (ano) {
      questoes = questoes.filter((q: QuestaoENEM) => q.ano === ano);
    }

    return questoes;
  } catch (error) {
    console.error('Erro ao buscar questões:', error);
    throw new Error('Não foi possível carregar as questões no momento. Tente novamente mais tarde.');
  }
}

export async function buscarQuestoesPorAssunto(assunto: string): Promise<QuestaoENEM[]> {
  try {
    // Primeiro busca todas as questões
    const todasQuestoes = await buscarQuestoes();
    
    // Filtra pelo assunto
    return todasQuestoes.filter((q: QuestaoENEM) => 
      q.assunto.toLowerCase().includes(assunto.toLowerCase())
    );
  } catch (error) {
    console.error('Erro ao buscar questões por assunto:', error);
    throw new Error('Não foi possível buscar questões para este assunto.');
  }
}

export async function gerarSimulado(materias: string[], quantidade: number = 10): Promise<QuestaoENEM[]> {
  try {
    // Buscar questões para cada matéria
    const questoesPorMateria = await Promise.all(
      materias.map(materia => buscarQuestoes(materia))
    );
    
    // Juntar todas as questões
    const todasQuestoes = questoesPorMateria.flat();
    
    // Embaralhar e selecionar a quantidade desejada
    return embaralharArray(todasQuestoes).slice(0, quantidade);
  } catch (error) {
    console.error('Erro ao gerar simulado:', error);
    throw new Error('Não foi possível gerar o simulado no momento.');
  }
}

function embaralharArray<T>(array: T[]): T[] {
  const novoArray = [...array];
  for (let i = novoArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [novoArray[i], novoArray[j]] = [novoArray[j], novoArray[i]];
  }
  return novoArray;
}