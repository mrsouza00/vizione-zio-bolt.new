import React, { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';

const CicloRevisao = () => {
  const [cicloCompleto, setCicloCompleto] = useState(false);

  const finalizarCiclo = () => {
    setCicloCompleto(true);
  };

  if (cicloCompleto) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-8">
        <Card className="glass-card p-8 text-center max-w-lg">
          <h2 className="text-2xl font-bold text-white mb-4">
            Parabéns!
          </h2>
          <p className="text-neutral-light mb-6">
            Volte amanhã e continue reforçando seus estudos de modo contínuo diariamente!
          </p>
          <Button className="gradient-button" onClick={() => window.location.href = '/'}>
            Voltar ao Início
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-8">
      <h1 className="text-3xl font-bold text-white mb-8">Ciclo de Revisão Diária</h1>
      
      <div className="space-y-6">
        <Card className="glass-card p-6">
          <h2 className="text-xl font-bold text-white mb-4">
            Questão 1 - Biologia Celular
          </h2>
          <p className="text-neutral-light mb-6">
            [Conteúdo da questão será inserido aqui]
          </p>
          <div className="space-y-4">
            {/* Opções de resposta */}
          </div>
        </Card>

        <div className="flex justify-end">
          <Button className="gradient-button" onClick={finalizarCiclo}>
            Finalizar Ciclo
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CicloRevisao;