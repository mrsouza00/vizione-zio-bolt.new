import React from 'react';
import { Card } from './ui/card';

const PainelDesempenho = () => {
  return (
    <div className="min-h-screen bg-background p-8">
      <div className="container mx-auto">
        <h1 className="text-3xl font-bold text-white mb-8">Painel de Desempenho</h1>
        
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card className="glass-card p-6">
            <div className="text-center">
              <h3 className="text-xl font-bold text-white mb-2">Questões Respondidas</h3>
              <div className="relative inline-flex items-center justify-center">
                <svg className="w-32 h-32">
                  <circle
                    className="text-purple-primary/10"
                    strokeWidth="8"
                    stroke="currentColor"
                    fill="transparent"
                    r="56"
                    cx="64"
                    cy="64"
                  />
                  <circle
                    className="text-purple-light"
                    strokeWidth="8"
                    strokeLinecap="round"
                    stroke="currentColor"
                    fill="transparent"
                    r="56"
                    cx="64"
                    cy="64"
                    strokeDasharray="350"
                    strokeDashoffset="100"
                  />
                </svg>
                <span className="absolute text-2xl font-bold text-white">75%</span>
              </div>
              <p className="text-neutral-light mt-2">1500 de 2000 questões</p>
            </div>
          </Card>

          <Card className="glass-card p-6">
            <div className="text-center">
              <h3 className="text-xl font-bold text-white mb-2">Tempo de Estudo</h3>
              <div className="text-4xl font-bold text-purple-light mb-2">69h</div>
              <p className="text-neutral-light">Neste mês</p>
            </div>
          </Card>

          <Card className="glass-card p-6">
            <div className="text-center">
              <h3 className="text-xl font-bold text-white mb-2">Média de Acertos</h3>
              <div className="text-4xl font-bold text-purple-light mb-2">82%</div>
              <p className="text-neutral-light">Últimos 30 dias</p>
            </div>
          </Card>
        </div>

        <div className="mt-8">
          <h2 className="text-2xl font-bold text-white mb-6">Desempenho por Área</h2>
          <div className="grid gap-6 md:grid-cols-2">
            {['Linguagens', 'Matemática', 'Ciências da Natureza', 'Ciências Humanas'].map(area => (
              <Card key={area} className="glass-card p-6">
                <h3 className="text-xl font-bold text-white mb-4">{area}</h3>
                <div className="h-4 bg-purple-primary/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-purple-primary to-purple-light"
                    style={{ width: `${Math.random() * 40 + 60}%` }}
                  />
                </div>
                <div className="mt-2 flex justify-between text-neutral-light">
                  <span>Acertos</span>
                  <span>{Math.floor(Math.random() * 40 + 60)}%</span>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PainelDesempenho;