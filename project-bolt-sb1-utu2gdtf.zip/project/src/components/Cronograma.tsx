import React, { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { ArrowLeft, ChevronDown, ChevronRight, CheckCircle2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Conteudo {
  nome: string;
  concluido: boolean;
}

interface SubArea {
  nome: string;
  conteudos: Conteudo[];
}

interface Area {
  nome: string;
  subAreas: SubArea[];
  expanded?: boolean;
}

const Cronograma = () => {
  const navigate = useNavigate();
  const [areas, setAreas] = useState<Area[]>([
    {
      nome: 'Ciências da Natureza',
      expanded: false,
      subAreas: [
        {
          nome: 'Biologia',
          conteudos: [
            { nome: 'Ecologia', concluido: false },
            { nome: 'Ecologia Avançada', concluido: false },
            { nome: 'Evolução', concluido: false },
            { nome: 'Impacto Ambiental', concluido: false },
            { nome: 'Moléculas Orgânicas', concluido: false },
            { nome: 'Transporte de Moléculas', concluido: false },
            { nome: 'Citologia', concluido: false },
            { nome: 'Energia Celular', concluido: false },
            { nome: 'Bactérias, Algas e Fungos', concluido: false },
            { nome: 'Filogenia e Introdução à Botânica', concluido: false },
            { nome: 'Morfologia e Reprodução de Plantas', concluido: false },
            { nome: 'Transporte de Seiva e de Sementes', concluido: false },
            { nome: 'Invertebrados', concluido: false },
            { nome: 'Parasitose e Doenças Endêmicas', concluido: false },
            { nome: 'Vertebrados e Conquista Terrestre', concluido: false },
            { nome: 'Sistema Digestório, Endócrino e Excretor', concluido: false },
            { nome: 'Sistema Reprodutor e Reprodução Humana', concluido: false },
            { nome: 'Sistema Cardiorrespiratório e Sangue', concluido: false },
            { nome: 'Sistema Nervoso e Musculoesquelético', concluido: false },
            { nome: 'Estrutura do DNA e Dogma Central', concluido: false },
            { nome: 'Genética', concluido: false },
            { nome: 'Hereditariedade', concluido: false },
            { nome: 'Genética Avançada', concluido: false },
            { nome: 'Vírus e Imunidade', concluido: false },
            { nome: 'Neoplasia e Farmacologia', concluido: false }
          ]
        },
        {
          nome: 'Química',
          conteudos: [
            { nome: 'Modelos Atômicos', concluido: false },
            { nome: 'Estrutura do Átomo', concluido: false },
            { nome: 'Camadas Eletrônicas', concluido: false },
            { nome: 'Tabela Periódica', concluido: false },
            { nome: 'Ligações Químicas', concluido: false },
            { nome: 'Reações Químicas', concluido: false },
            { nome: 'Ácido e Base', concluido: false },
            { nome: 'Reações com Ácido', concluido: false },
            { nome: 'Sais e Óxidos', concluido: false },
            { nome: 'Estequiometria', concluido: false },
            { nome: 'Equilíbrio Químico', concluido: false },
            { nome: 'Termoquímica', concluido: false },
            { nome: 'Reações Orgânicas', concluido: false },
            { nome: 'Química Orgânica', concluido: false },
            { nome: 'Ciclos da Matéria', concluido: false },
            { nome: 'Descarte de Materiais', concluido: false },
            { nome: 'Reações Nucleares', concluido: false }
          ]
        },
        {
          nome: 'Física',
          conteudos: [
            { nome: 'Eletromagnetismo', concluido: false },
            { nome: 'Eletricidade', concluido: false },
            { nome: 'Eletrodinâmica', concluido: false },
            { nome: 'Termodinâmica e Energia Mecânica', concluido: false },
            { nome: 'Estudo dos Gases', concluido: false },
            { nome: 'Cinemática', concluido: false },
            { nome: 'Dinâmica', concluido: false },
            { nome: 'Gravitação', concluido: false },
            { nome: 'Hidrostática', concluido: false },
            { nome: 'Óptica', concluido: false },
            { nome: 'Fenômenos Ópticos', concluido: false },
            { nome: 'Ondulatória', concluido: false },
            { nome: 'Ondulatória Avançada e Acústica', concluido: false },
            { nome: 'Escalas de Temperatura', concluido: false }
          ]
        }
      ]
    },
    {
      nome: 'Ciências Humanas',
      expanded: false,
      subAreas: [
        {
          nome: 'História',
          conteudos: [
            { nome: 'Antiguidade Oriental', concluido: false },
            { nome: 'Revolução Científica', concluido: false },
            { nome: 'Ascensão do Feudalismo', concluido: false },
            { nome: 'Imperialismo', concluido: false },
            { nome: 'Totalitarismo e Segunda Grande Guerra', concluido: false },
            { nome: 'Guerra Fria', concluido: false },
            { nome: 'Era Vargas', concluido: false },
            { nome: 'República Populista', concluido: false },
            { nome: 'Ditadura e Nova República', concluido: false },
            { nome: 'Ciclos Econômicos Brasileiros', concluido: false },
            { nome: 'Revolução Industrial', concluido: false },
            { nome: 'Kant e Nietzsche', concluido: false }
          ]
        },
        {
          nome: 'Geografia',
          conteudos: [
            { nome: 'Cartografia e Meteorologia', concluido: false },
            { nome: 'Tectonismo', concluido: false },
            { nome: 'Estrutura Geológica e Formação de Rochas', concluido: false },
            { nome: 'Relevo Brasileiro', concluido: false },
            { nome: 'Clima Brasileiro', concluido: false },
            { nome: 'Massas de Ar e Correntes Marítimas', concluido: false },
            { nome: 'Hidrografia Brasileira', concluido: false },
            { nome: 'Impacto Ambiental', concluido: false },
            { nome: 'Globalização e Precarização do Trabalho', concluido: false },
            { nome: 'Urbanização', concluido: false }
          ]
        }
      ]
    },
    {
      nome: 'Linguagens',
      expanded: false,
      subAreas: [
        {
          nome: 'Língua Portuguesa',
          conteudos: [
            { nome: 'Gêneros e Tipos Textuais', concluido: false },
            { nome: 'Linguística e Formação do Português', concluido: false },
            { nome: 'Variantes Linguísticas', concluido: false },
            { nome: 'Linguagem Formal e Informal', concluido: false },
            { nome: 'Análise de Poemas', concluido: false },
            { nome: 'Estrutura Sintática', concluido: false },
            { nome: 'Concordância', concluido: false },
            { nome: 'Recursos Expressivos', concluido: false },
            { nome: 'Figuras de Linguagem', concluido: false },
            { nome: 'Argumentação e Progressão Temática', concluido: false }
          ]
        },
        {
          nome: 'Artes',
          conteudos: [
            { nome: 'Artes e Expressão Artística no Brasil', concluido: false },
            { nome: 'Modernismo', concluido: false },
            { nome: 'Vanguarda Europeia', concluido: false },
            { nome: 'História da Arte', concluido: false }
          ]
        },
        {
          nome: 'Filosofia e Sociologia',
          conteudos: [
            { nome: 'Ideologia de Gênero', concluido: false },
            { nome: 'Direitos Humanos e Luta Social', concluido: false },
            { nome: 'Preconceito e Violência contra a Mulher', concluido: false },
            { nome: 'Segregação Racial e Lutas Sociais', concluido: false }
          ]
        }
      ]
    },
    {
      nome: 'Matemática',
      expanded: false,
      subAreas: [
        {
          nome: 'Matemática Básica',
          conteudos: [
            { nome: 'Operações fundamentais', concluido: false },
            { nome: 'MMC e MDC', concluido: false },
            { nome: 'Potenciação', concluido: false },
            { nome: 'Regras de potenciação', concluido: false },
            { nome: 'Radiciação', concluido: false },
            { nome: 'Porcentagem e Conversões', concluido: false },
            { nome: 'Cálculo de porcentagens', concluido: false },
            { nome: 'Conversão entre frações e porcentagens', concluido: false },
            { nome: 'Razão e Matemática Financeira', concluido: false },
            { nome: 'Cálculo de razões', concluido: false },
            { nome: 'Juros simples e compostos', concluido: false },
            { nome: 'Equação de 1º Grau', concluido: false },
            { nome: 'Resolução de equações lineares', concluido: false },
            { nome: 'Sistemas e Vazão', concluido: false },
            { nome: 'Resolução de sistemas de equações', concluido: false },
            { nome: 'Cálculo de vazão', concluido: false },
            { nome: 'Estatística Básica', concluido: false },
            { nome: 'Média, mediana, moda e desvio padrão', concluido: false },
            { nome: 'Progressões Matemáticas', concluido: false },
            { nome: 'Progressões aritméticas e geométricas', concluido: false },
            { nome: 'Equação de 2º Grau', concluido: false },
            { nome: 'Fórmulas de Bhaskara', concluido: false },
            { nome: 'Análise de raízes', concluido: false },
            { nome: 'Análise de Gráficos', concluido: false },
            { nome: 'Interpretação de gráficos e tabelas', concluido: false },
            { nome: 'Diagrama de Venn e Mapas', concluido: false },
            { nome: 'Uso de diagramas para resolver problemas de conjuntos', concluido: false },
            { nome: 'Paralelogramos, Triângulos, Círculos e Projeções', concluido: false },
            { nome: 'Cálculo de áreas e perímetros', concluido: false },
            { nome: 'Prismas e Pirâmides', concluido: false },
            { nome: 'Cálculo de volume e área de superfície', concluido: false },
            { nome: 'Esferas, Cones e Cilindros', concluido: false },
            { nome: 'Análise Combinatória', concluido: false },
            { nome: 'Princípios de contagem e combinações', concluido: false },
            { nome: 'Probabilidade', concluido: false },
            { nome: 'Cálculo de probabilidades simples', concluido: false }
          ]
        }
      ]
    }
  ]);

  const toggleArea = (areaIndex: number) => {
    setAreas(prev => prev.map((area, index) => 
      index === areaIndex ? { ...area, expanded: !area.expanded } : area
    ));
  };

  const toggleConteudo = (areaIndex: number, subAreaIndex: number, conteudoIndex: number) => {
    setAreas(prev => prev.map((area, ai) => 
      ai === areaIndex ? {
        ...area,
        subAreas: area.subAreas.map((subArea, si) => 
          si === subAreaIndex ? {
            ...subArea,
            conteudos: subArea.conteudos.map((conteudo, ci) => 
              ci === conteudoIndex ? { ...conteudo, concluido: !conteudo.concluido } : conteudo
            )
          } : subArea
        )
      } : area
    ));
  };

  const calcularProgresso = (subArea: SubArea) => {
    const total = subArea.conteudos.length;
    const concluidos = subArea.conteudos.filter(c => c.concluido).length;
    return (concluidos / total) * 100;
  };

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="container mx-auto max-w-4xl">
        <button 
          onClick={() => navigate('/')} 
          className="text-white mb-6 flex items-center hover:text-purple-light transition-colors"
        >
          <ArrowLeft className="h-6 w-6 mr-2" />
          Voltar
        </button>

        <h1 className="text-3xl font-bold text-white mb-8">Cronograma de Estudos</h1>

        <div className="space-y-6">
          {areas.map((area, areaIndex) => (
            <Card key={area.nome} className="glass-card overflow-hidden">
              <button
                className="w-full p-6 flex items-center justify-between text-left hover:bg-white/5 transition-colors"
                onClick={() => toggleArea(areaIndex)}
              >
                <h2 className="text-2xl font-bold text-white">{area.nome}</h2>
                {area.expanded ? (
                  <ChevronDown className="h-6 w-6 text-purple-light" />
                ) : (
                  <ChevronRight className="h-6 w-6 text-purple-light" />
                )}
              </button>

              {area.expanded && (
                <div className="border-t border-purple-light/20">
                  {area.subAreas.map((subArea, subAreaIndex) => (
                    <div key={subArea.nome} className="p-6 border-b border-purple-light/10 last:border-b-0">
                      <h3 className="text-xl font-semibold text-purple-light mb-4">{subArea.nome}</h3>
                      
                      <div className="mb-4">
                        <div className="h-2 bg-purple-primary/10 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-purple-primary to-purple-light transition-all duration-300"
                            style={{ width: `${calcularProgresso(subArea)}%` }}
                          />
                        </div>
                        <p className="text-sm text-neutral-light mt-1">
                          {subArea.conteudos.filter(c => c.concluido).length} de {subArea.conteudos.length} concluídos
                        </p>
                      </div>

                      <div className="space-y-2">
                        {subArea.conteudos.map((conteudo, conteudoIndex) => (
                          <button
                            key={conteudo.nome}
                            onClick={() => toggleConteudo(areaIndex, subAreaIndex, conteudoIndex)}
                            className="w-full flex items-center p-2 rounded-lg hover:bg-white/5 transition-colors group"
                          >
                            <div className="relative flex items-center justify-center">
                              <div className={`h-5 w-5 rounded-full border-2 transition-colors ${
                                conteudo.concluido ? 'border-purple-light bg-purple-light' : 'border-purple-light/50'
                              }`} />
                              {conteudo.concluido && (
                                <CheckCircle2 className="h-4 w-4 text-white absolute" />
                              )}
                            </div>
                            <span className={`ml-3 ${
                              conteudo.concluido ? 'text-neutral-light line-through' : 'text-white'
                            } group-hover:text-purple-light transition-colors`}>
                              {conteudo.nome}
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Cronograma;