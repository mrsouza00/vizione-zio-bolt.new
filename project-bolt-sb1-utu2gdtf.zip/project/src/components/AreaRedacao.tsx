import React, { useState, useEffect, useRef } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { ArrowLeft, Clock, Download, Save, PenTool } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Redacao {
  id: string;
  tema: string;
  data: string;
  nota: number;
  comentarios: string;
  textoMotivador1?: string;
  textoMotivador2?: string;
  textoMotivador3?: string;
}

interface RedacaoState {
  conteudo: string;
  contadorPalavras: number;
  tempoDecorrido: number;
  timerAtivo: boolean;
  salvamentoAutomatico: boolean;
  temaAtual: string;
  textosMotivadores: {
    texto1?: string;
    texto2?: string;
    texto3?: string;
  };
  modoEdicao: boolean;
}

const TEMA_EXEMPLO = {
  tema: "Desafios para a valorização da herança africana no Brasil",
  textoMotivador1: `**Texto I — Definição da palavra "herança" no dicionário**

O primeiro texto de apoio do tema de redação Enem 2024 foi o verbete da palavra "herança", segundo o dicionário Houaiss da língua portuguesa, explicando, portanto, o significado da mesma:

"Herança — o legado de crenças, conhecimentos, técnicas, costumes, tradições, transmitido por um grupo social de geração para geração; cultura."`,
  textoMotivador2: `**Texto II — A epistemologia da ancestralidade**

O texto dois trazia um trecho do artigo "A epistemologia da ancestralidade, escrito por Eduardo Oliveira e publicado na revista Entrelugares:

"As culturas africanas e afro-brasileiras foram relegadas ao campo do folclore com o propósito de confiná-las ao gueto fossilizado da memória. Folclorizar, nesse caso, é reduzir uma cultura a um conjunto de representações estereotipadas, via de regra, alheias ao contexto que produziu essa cultura."`,
  textoMotivador3: `**Texto III — Provérbio africano ilustrado**

Um provérbio africano foi utilizado como terceiro texto da coletânea de apoio do tema de redação do Enem 2024, acompanhada por uma ilustração publicada no livro "Um defeito de cor" de Ana Maria Gonçalves. A frase diz: "Quando não souberes para onde ir, olha para trás e saiba pelo menos de onde vens". A ilustração é da artista Rosana Paulino.`
};

const AreaRedacao = () => {
  const navigate = useNavigate();
  const [estado, setEstado] = useState<RedacaoState>({
    conteudo: '',
    contadorPalavras: 0,
    tempoDecorrido: 0,
    timerAtivo: false,
    salvamentoAutomatico: true,
    temaAtual: '',
    textosMotivadores: {},
    modoEdicao: false
  });

  const [mostrarModal, setMostrarModal] = useState(false);
  const [modalConteudo, setModalConteudo] = useState<'tema' | 'criar' | null>(null);
  const [temaPersonalizado, setTemaPersonalizado] = useState('');

  const editorRef = useRef<HTMLTextAreaElement>(null);
  const timerRef = useRef<NodeJS.Timeout>();

  // Contador de palavras
  const atualizarContador = (texto: string) => {
    const palavras = texto.trim().split(/\s+/).filter(word => word.length > 0);
    setEstado(prev => ({
      ...prev,
      conteudo: texto,
      contadorPalavras: palavras.length
    }));
  };

  // Timer
  useEffect(() => {
    if (estado.timerAtivo) {
      timerRef.current = setInterval(() => {
        setEstado(prev => ({
          ...prev,
          tempoDecorrido: prev.tempoDecorrido + 1
        }));
      }, 1000);
    }
    return () => clearInterval(timerRef.current);
  }, [estado.timerAtivo]);

  const formatarTempo = (segundos: number) => {
    const horas = Math.floor(segundos / 3600);
    const minutos = Math.floor((segundos % 3600) / 60);
    const segs = segundos % 60;
    return `${horas.toString().padStart(2, '0')}:${minutos.toString().padStart(2, '0')}:${segs.toString().padStart(2, '0')}`;
  };

  const gerarTemaSurpresa = () => {
    // Simular tema surpresa com o exemplo fornecido
    setEstado(prev => ({
      ...prev,
      temaAtual: TEMA_EXEMPLO.tema,
      textosMotivadores: {
        texto1: TEMA_EXEMPLO.textoMotivador1,
        texto2: TEMA_EXEMPLO.textoMotivador2,
        texto3: TEMA_EXEMPLO.textoMotivador3
      },
      modoEdicao: true
    }));
    setMostrarModal(true);
    setModalConteudo('tema');
  };

  const criarTemaPersonalizado = () => {
    if (temaPersonalizado.trim()) {
      setEstado(prev => ({
        ...prev,
        temaAtual: temaPersonalizado,
        modoEdicao: true
      }));
      setMostrarModal(false);
      setTemaPersonalizado('');
    }
  };

  const finalizarRedacao = () => {
    // Simular correção automática
    const redacaoCorrigida: Redacao = {
      id: Date.now().toString(),
      tema: estado.temaAtual,
      data: new Date().toISOString(),
      nota: Math.floor(Math.random() * 200) + 800, // Simulação de nota entre 800 e 1000
      comentarios: `Competência 1: 200/200 - Excelente domínio da norma culta
Competência 2: 180/200 - Boa compreensão da proposta
Competência 3: 180/200 - Argumentação consistente
Competência 4: 180/200 - Boa articulação das ideias
Competência 5: 180/200 - Proposta de intervenção bem elaborada

Comentário do corretor Vizione:
Sua redação demonstra excelente domínio da norma culta e boa compreensão do tema proposto. 
A argumentação é consistente e bem desenvolvida. Para melhorar ainda mais, sugiro:
- Aprofundar mais os argumentos com dados estatísticos
- Desenvolver melhor a conclusão
- Revisar alguns aspectos de pontuação`
    };

    // Salvar no localStorage (simulando banco de dados)
    const redacoesAnteriores = JSON.parse(localStorage.getItem('redacoes') || '[]');
    localStorage.setItem('redacoes', JSON.stringify([...redacoesAnteriores, redacaoCorrigida]));

    // Resetar estado
    setEstado(prev => ({
      ...prev,
      conteudo: '',
      contadorPalavras: 0,
      tempoDecorrido: 0,
      timerAtivo: false,
      modoEdicao: false
    }));

    // Redirecionar para a lista de redações
    navigate('/redacoes');
  };

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="container mx-auto max-w-4xl">
        <div className="flex items-center justify-between mb-8">
          <button 
            onClick={() => navigate('/')} 
            className="text-white flex items-center hover:text-purple-light transition-colors"
          >
            <ArrowLeft className="h-6 w-6 mr-2" />
            Voltar
          </button>
          
          {estado.modoEdicao && (
            <div className="flex items-center space-x-4">
              <Clock className="h-5 w-5 text-purple-light" />
              <span className="text-white font-mono">{formatarTempo(estado.tempoDecorrido)}</span>
              <Button
                onClick={() => setEstado(prev => ({ ...prev, timerAtivo: !prev.timerAtivo }))}
                className="gradient-button"
              >
                {estado.timerAtivo ? 'Pausar' : 'Iniciar'} Timer
              </Button>
            </div>
          )}
        </div>

        {!estado.modoEdicao ? (
          <div className="grid gap-6 md:grid-cols-2">
            <Card className="glass-card p-6 hover:border-purple-light/50 transition-colors cursor-pointer">
              <div className="mb-6 flex items-center justify-between">
                <PenTool className="h-8 w-8 text-purple-light" />
                <span className="rounded-full bg-purple-primary/10 px-3 py-1 text-sm text-purple-light">
                  Surpresa
                </span>
              </div>
              <h3 className="text-xl font-bold text-white mb-4">Gerar Tema Surpresa</h3>
              <p className="text-neutral-light mb-6">
                Receba um tema surpresa com textos motivadores gerados automaticamente
              </p>
              <Button 
                className="w-full gradient-button"
                onClick={gerarTemaSurpresa}
              >
                Gerar Tema Surpresa
              </Button>
            </Card>

            <Card className="glass-card p-6 hover:border-purple-light/50 transition-colors cursor-pointer">
              <div className="mb-6 flex items-center justify-between">
                <PenTool className="h-8 w-8 text-purple-light" />
                <span className="rounded-full bg-purple-primary/10 px-3 py-1 text-sm text-purple-light">
                  Personalizado
                </span>
              </div>
              <h3 className="text-xl font-bold text-white mb-4">Criar Tema</h3>
              <p className="text-neutral-light mb-6">
                Digite seu próprio tema e receba textos motivadores personalizados
              </p>
              <Button 
                className="w-full gradient-button"
                onClick={() => {
                  setMostrarModal(true);
                  setModalConteudo('criar');
                }}
              >
                Criar Tema
              </Button>
            </Card>
          </div>
        ) : (
          <>
            <Card className="glass-card mb-6">
              <div className="p-6">
                <h2 className="text-2xl font-bold text-white mb-4">{estado.temaAtual}</h2>
                
                {Object.entries(estado.textosMotivadores).map(([key, texto], index) => (
                  texto && (
                    <div key={key} className="mb-6 text-white">
                      <div className="prose prose-invert max-w-none">
                        {texto.split('\n\n').map((paragrafo, i) => (
                          <p key={i} className="mb-4">{paragrafo}</p>
                        ))}
                      </div>
                    </div>
                  )
                ))}

                <div className="relative mb-4">
                  <p className="text-white mb-2">Digite sua redação aqui:</p>
                  <textarea
                    ref={editorRef}
                    className="w-full h-96 p-4 bg-background/50 text-white rounded-lg border border-purple-light/30 focus:border-purple-light focus:ring-2 focus:ring-purple-light/20 focus:outline-none resize-none"
                    value={estado.conteudo}
                    onChange={(e) => atualizarContador(e.target.value)}
                    spellCheck="true"
                  />
                  
                  <div className="absolute bottom-4 right-4 text-neutral-light text-sm">
                    {estado.contadorPalavras} palavras
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <Button
                    onClick={() => setEstado(prev => ({ ...prev, salvamentoAutomatico: !prev.salvamentoAutomatico }))}
                    className={`flex items-center space-x-2 ${estado.salvamentoAutomatico ? 'text-purple-light' : 'text-neutral-light'}`}
                  >
                    <Save className="h-4 w-4" />
                    <span>Auto-save {estado.salvamentoAutomatico ? 'Ativado' : 'Desativado'}</span>
                  </Button>

                  <Button
                    onClick={finalizarRedacao}
                    className="gradient-button"
                  >
                    Finalizar Redação
                  </Button>
                </div>
              </div>
            </Card>

            <div className="text-neutral-light text-sm">
              <p>Dicas:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>Use o timer para simular o tempo real do ENEM</li>
                <li>Seu texto é salvo automaticamente a cada modificação</li>
                <li>Mantenha entre 2500 e 3000 caracteres</li>
                <li>Verifique a ortografia antes de finalizar</li>
              </ul>
            </div>
          </>
        )}

        {/* Modal para Tema Personalizado */}
        {mostrarModal && modalConteudo === 'criar' && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <Card className="glass-card w-full max-w-lg p-6">
              <h3 className="text-xl font-bold text-white mb-4">Digite seu tema</h3>
              <textarea
                className="w-full h-32 p-4 bg-background/50 text-white rounded-lg border border-purple-light/30 focus:border-purple-light focus:ring-2 focus:ring-purple-light/20 focus:outline-none resize-none mb-4"
                value={temaPersonalizado}
                onChange={(e) => setTemaPersonalizado(e.target.value)}
                placeholder="Digite o tema da redação..."
              />
              <div className="flex justify-end space-x-4">
                <Button onClick={() => setMostrarModal(false)}>Cancelar</Button>
                <Button onClick={criarTemaPersonalizado} className="gradient-button">
                  Criar Tema
                </Button>
              </div>
            </Card>
          </div>
        )}

        {/* Modal para Tema Surpresa */}
        {mostrarModal && modalConteudo === 'tema' && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <Card className="glass-card w-full max-w-4xl p-6">
              <h3 className="text-xl font-bold text-white mb-4">{estado.temaAtual}</h3>
              {Object.entries(estado.textosMotivadores).map(([key, texto], index) => (
                texto && (
                  <div key={key} className="mb-6 text-white">
                    <div className="prose prose-invert max-w-none">
                      {texto.split('\n\n').map((paragrafo, i) => (
                        <p key={i} className="mb-4">{paragrafo}</p>
                      ))}
                    </div>
                  </div>
                )
              ))}
              <div className="flex justify-end space-x-4">
                <Button onClick={() => setMostrarModal(false)} className="gradient-button">
                  Começar a Escrever
                </Button>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default AreaRedacao;