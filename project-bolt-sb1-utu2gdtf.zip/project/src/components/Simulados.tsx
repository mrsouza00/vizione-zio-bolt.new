import React, { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { ArrowLeft, Clock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Simulados = () => {
  const navigate = useNavigate();
  const [selectedDay, setSelectedDay] = useState<string | null>(null);
  const [timer, setTimer] = useState<number>(0);
  const [isTimerRunning, setIsTimerRunning] = useState(false);

  React.useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerRunning) {
      interval = setInterval(() => {
        setTimer(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning]);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="container mx-auto">
        <button 
          onClick={() => navigate('/')} 
          className="text-white mb-6 flex items-center hover:text-purple-light transition-colors"
        >
          <ArrowLeft className="h-6 w-6 mr-2" />
          Voltar
        </button>

        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-white">Escolha as seguintes opções:</h1>
          {selectedDay && (
            <div className="flex items-center space-x-4">
              <Clock className="h-5 w-5 text-purple-light" />
              <span className="text-white text-xl font-mono">{formatTime(timer)}</span>
            </div>
          )}
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card className="glass-card p-6 hover:border-purple-light/50 transition-colors cursor-pointer">
            <h2 className="text-2xl font-bold text-white mb-4">Primeiro Dia</h2>
            <p className="text-neutral-light mb-6">
              Questões de Linguagens e Códigos, Ciências Humanas e Redação
            </p>
            <Button 
              className="w-full gradient-button"
              onClick={() => {
                setSelectedDay('primeiro');
                setIsTimerRunning(true);
              }}
            >
              Iniciar Simulado
            </Button>
          </Card>

          <Card className="glass-card p-6 hover:border-purple-light/50 transition-colors cursor-pointer">
            <h2 className="text-2xl font-bold text-white mb-4">Segundo Dia</h2>
            <p className="text-neutral-light mb-6">
              Questões de Ciências da Natureza e Matemática
            </p>
            <Button 
              className="w-full gradient-button"
              onClick={() => {
                setSelectedDay('segundo');
                setIsTimerRunning(true);
              }}
            >
              Iniciar Simulado
            </Button>
          </Card>
        </div>

        {selectedDay && (
          <div className="mt-8">
            {/* Aqui será renderizado o conteúdo do simulado baseado no dia selecionado */}
          </div>
        )}
      </div>
    </div>
  );
};

export default Simulados;