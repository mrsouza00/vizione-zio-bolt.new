/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      container: {
        center: true,
        padding: '2rem',
        screens: {
          '2xl': '1400px',
        },
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      },
      colors: {
        'purple-primary': '#6D28D9',
        'purple-light': '#8B5CF6',
        'neutral-light': '#9CA3AF',
        background: '#0A0A0B',
      },
    },
  },
  plugins: [],
};